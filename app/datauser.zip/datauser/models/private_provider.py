# from .user import User
# from ...extensions import mongo
# from datetime import datetime, timezone
# import uuid

# class PrivateDataProvider(User):
#     """Private Data Provider (Level 3): Can manage courses and configure services."""

#     SERVICE_COLLECTION = "SERVICE_CONFIG"
#     COURSE_COLLECTION = "COURSE_INFO"

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)

#     @staticmethod
#     def is_eligible(user: User) -> bool:
#         return (
#             isinstance(user.role, User.Roles)
#             and user.access_level[2] is True  # Level 3 权限
#         )

#     def add_course(self, course_data: dict) -> str:
#         required_fields = {"title", "units", "description"}
#         if not required_fields.issubset(course_data):
#             return "COURSE_DATA_INVALID"

#         # 检查重复（按标题+学分+组织）
#         exists = mongo.db[self.COURSE_COLLECTION].find_one({
#             "title": course_data["title"],
#             "units": course_data["units"],
#             "organization": self._extract_org_from_email()
#         })
#         if exists:
#             return "COURSE_ALREADY_EXISTS"

#         course_data.update({
#             "_id": str(uuid.uuid4()),
#             "provider_email": self.email,
#             "organization": self._extract_org_from_email(),
#             "created_at": datetime.now(timezone.utc)
#         })

#         mongo.db[self.COURSE_COLLECTION].insert_one(course_data)
#         return course_data["_id"]


#     def edit_course(self, course_id: str, new_data: dict) -> str:
#         result = mongo.db[self.COURSE_COLLECTION].update_one(
#             {"_id": course_id, "provider_email": self.email},
#             {"$set": new_data}
#         )
#         return "COURSE_UPDATED" if result.modified_count else "COURSE_NOT_FOUND"

#     def delete_course(self, course_id: str) -> str:
#         result = mongo.db[self.COURSE_COLLECTION].delete_one(
#             {"_id": course_id, "provider_email": self.email}
#         )
#         return "COURSE_DELETED" if result.deleted_count else "COURSE_NOT_FOUND"

#     def list_courses(self) -> list:
#         return list(mongo.db[self.COURSE_COLLECTION].find(
#             {"provider_email": self.email}, {"_id": 0}
#         ))

#     def configure_service(self, service_name: str, config: dict) -> str:
#         required_fields = {"base_url", "path", "method", "input", "output"}
#         if not required_fields.issubset(config):
#             return "SERVICE_CONFIG_INVALID"

#         record = {
#             "provider_email": self.email,
#             "organization": self._extract_org_from_email(),
#             "service_name": service_name,
#             "config": config,
#             "created_at": datetime.now(timezone.utc)
#         }

#         mongo.db[self.SERVICE_COLLECTION].replace_one(
#             {"provider_email": self.email, "service_name": service_name},
#             record,
#             upsert=True
#         )
#         return "SERVICE_CONFIGURED"

#     def delete_service_config(self, service_name: str) -> str:
#         result = mongo.db[self.SERVICE_COLLECTION].delete_one(
#             {"provider_email": self.email, "service_name": service_name}
#         )
#         return "SERVICE_CONFIG_DELETED" if result.deleted_count else "SERVICE_CONFIG_NOT_FOUND"

#     def list_service_configs(self) -> list:
#         return list(mongo.db[self.SERVICE_COLLECTION].find(
#             {"provider_email": self.email}, {"_id": 0}
#         ))

#     def _extract_org_from_email(self) -> str:
#         return self.email.split('@')[-1].split('.')[0].lower()

from pymongo import MongoClient
from app import mongo
from flask import current_app
from pymongo.errors import PyMongoError
from ..models.service_config import ServiceConfig
from ..models.course_info import CourseInfo
from app.main.User import User
import requests
from datetime import datetime, timezone
import uuid

class PrivateDataProvider(User):
    SERVICE_COLLECTION = "SERVICE_CONFIG"
    COURSE_COLLECTION = "COURSE_INFO"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.organization = self._extract_org_from_email()

    @staticmethod
    def is_eligible(user: User) -> bool:
        return user.access_level[2] is True

    def _extract_org_from_email(self) -> str | None:
        """
        Safely extracts the organization name from the provider's email.
        Returns organization name in lowercase or None if extraction fails.
        """
        if not self.email or not isinstance(self.email, str) or '@' not in self.email:
            current_app.logger.error(f"Cannot extract organization: Invalid email for provider: {self.email}")
            return None
        try:
            # Example: "user@example.com" -> "example"
            # Example: "user@dept.example.com" -> "dept" (if domain has multiple parts, takes the first part of domain)
            # If you want the full domain like "example.com", adjust accordingly.
            # The original logic implied taking the first part of the domain before the first dot.
            domain_part = self.email.split('@')[-1]
            return domain_part.split('.')[0].lower()
        except IndexError:
            current_app.logger.error(f"Cannot extract organization: Error parsing email: {self.email}")
            return None

    def add_course(self, course_data: dict) -> str:
        required_fields = {"title", "units", "description"}
        if not required_fields.issubset(course_data):
            current_app.logger.warning(f"Add course failed: Missing required fields. Data: {course_data}")
            return "COURSE_DATA_INVALID"

        if not self.email:
            current_app.logger.error("Add course failed: Provider email is missing.")
            return "PROVIDER_EMAIL_MISSING" # 新的错误代码

        organization = self._extract_org_from_email()
        if not organization:
            # _extract_org_from_email 内部已经记录了错误
            return "ORGANIZATION_EXTRACTION_FAILED" # 新的错误代码

        try:
            # 检查重复（按标题+学分+组织）
            exists = mongo.db[self.COURSE_COLLECTION].find_one({
                "title": course_data["title"],
                "units": course_data["units"], # 确保单位也用于查重
                "organization": organization
            })
            if exists:
                current_app.logger.info(f"Add course attempt failed: Course already exists. Data: {course_data}, Org: {organization}")
                return "COURSE_ALREADY_EXISTS"

            # 准备要插入的数据
            # 不直接修改传入的 course_data，而是创建一个新的字典，除非明确这是期望的行为
            new_course_doc = {
                "_id": str(uuid.uuid4()),
                #_id mongoDB会自己处理赋值一个ObjectId
                "title": course_data["title"],
                "units": course_data["units"],
                "description": course_data["description"],
                "provider_email": self.email,
                "organization": organization,
                "created_at": datetime.now(timezone.utc)
            }
            # 如果 course_data 中有其他允许的字段，也可以在这里合并

            mongo.db[self.COURSE_COLLECTION].insert_one(new_course_doc)
            current_app.logger.info(f"Course added successfully by {self.email}: {new_course_doc['_id']} - {new_course_doc['title']}")
            course_data.update(new_course_doc) # 更新原始字典以包含新生成的字段
            return "COURSE_ADDED"

        except PyMongoError as e:
            current_app.logger.error(f"MongoDB error during add_course by {self.email}: {e}")
            return "DATABASE_ERROR" # 新的错误代码
        except Exception as e:
            # 捕获任何其他意外错误
            current_app.logger.error(f"Unexpected error in add_course by {self.email}: {e}", exc_info=True) # exc_info=True 会记录堆栈跟踪
            return "UNEXPECTED_ERROR" # 新的错误代码


    def list_courses(self) -> list:
        """Lists courses provided by this provider."""
        if not self.email:
            current_app.logger.error("List courses failed: Provider email is missing.")
            return [] # 返回空列表或引发错误
        try:
            # 确保 CourseInfo.find_by_provider(self.email) 返回的是包含 _id 的完整文档
            # 从您提供的 course_info.py 片段看，它会包含 _id
            return CourseInfo.find_by_provider(self.email)
        except PyMongoError as e:
            current_app.logger.error(f"MongoDB error during list_courses for {self.email}: {e}")
            return [] # 或者根据策略处理
        except Exception as e:
            current_app.logger.error(f"Unexpected error in list_courses for {self.email}: {e}", exc_info=True)
            return []

    def update_course(self, course_id: str, update_data: dict) -> bool:
        return CourseInfo.update_by_id(course_id, self.email, update_data)

    def delete_course(self, course_id: str) -> bool:
        return CourseInfo.delete_by_id(course_id, self.email)

    def list_courses(self) -> list:
        return CourseInfo.find_by_provider(self.email)

    def add_service_config(self, service_data: dict) -> str:
        return ServiceConfig.save(self.email, self.organization, service_data)

    def delete_service_config(self, service_name: str) -> bool:
        return ServiceConfig.delete(self.email, service_name)

    def list_service_configs(self) -> list:
        return ServiceConfig.find_by_provider(self.email)

    def test_service_config(self, service_name: str, test_input: dict) -> dict:
        config_entry = ServiceConfig.find_by_service(self.organization, service_name)
        if not config_entry:
            return {"error": "SERVICE_NOT_FOUND"}
        try:
            config = config_entry["config"]
            url = f"{config['base_url'].rstrip('/')}/{config['path'].lstrip('/')}"
            method = config["method"].upper()
            response = requests.request(method, url, json=test_input, timeout=3)
            return {
                "status": "success" if response.status_code < 400 else "failed",
                "response": response.json()
            }
        except Exception as e:
            return {"error": f"DISPATCH_FAILED: {str(e)}"}

