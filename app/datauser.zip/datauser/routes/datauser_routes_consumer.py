from flask import Blueprint, request, jsonify, send_file, render_template
from flask import current_app as app
from ..models.service_config import ServiceConfig
from ..services.interface_dispatcher import dispatch_service_request
from ..models.public_consumer import PublicDataConsumer
from ..models.private_consumer import PrivateDataConsumer
from ...extensions import mongo, get_db
from datetime import datetime, timezone
import requests
import os

consumer_bp = Blueprint("consumer", __name__, url_prefix="/api/consumer")

def get_user_email():
    return request.headers.get("X-User-Email", "")

# 🔍 1. Search or List Public Courses
@consumer_bp.route("/courses", methods=["GET"])
def search_courses():
    keyword = request.args.get("keyword", "").strip()
    consumer = PublicDataConsumer({})
    if keyword:
        results = consumer.search_courses(keyword)
    else:
        results = consumer.list_all_courses()
    return jsonify(results)

# 📘 1b. List All Courses (no keyword)
@consumer_bp.route("/courses/all", methods=["GET"])
def list_all_courses():
    courses = list(mongo.db.COURSE_INFO.find({}, {"_id": 0}))
    return jsonify(courses)

@consumer_bp.route("/courses/list", methods=["GET"])
def list_show_courses():
    consumer = PublicDataConsumer({})
    return render_template("datauser/course.html", courses = consumer.list_all_courses())

# 📗 1c. List All Theses
@consumer_bp.route("/theses", methods=["GET"])
def list_theses():
    theses = list(mongo.db.THESIS.find({}, {"_id": 0, "pdf_path": 0}))
    return jsonify(theses)

# 📄 2. View Thesis Metadata
@consumer_bp.route("/thesis/metadata", methods=["GET"])
def view_thesis_metadata():
    title = request.args.get("title", "").strip()
    if not title:
        return jsonify({"error": "MISSING_TITLE"}), 400

    record = mongo.db.THESIS.find_one({"title": {"$regex": title, "$options": "i"}})
    if not record:
        return jsonify({"message": "NOT_FOUND"}), 404

    return jsonify({
        "thesis_id": record.get("_id"),
        "title": record.get("title"),
        "abstract": record.get("abstract"),
        "price": record.get("price", 0)
    })

# 📊 3. View Quota Info
@consumer_bp.route("/quota", methods=["GET"])
def check_quota():
    email = request.args.get("email", "").strip()
    if not email:
        return jsonify({"error": "MISSING_EMAIL"}), 400

    record = mongo.db.USER_QUOTA.find_one({"user_email": email}) or {}
    return jsonify({
        "used_today": record.get("used_today", 0),
        "max_daily": record.get("max_daily", 5),
        "last_used": record.get("last_used")
    })

# 💰 4. Check Account Balance
@consumer_bp.route("/bank/balance", methods=["POST"])
def check_balance():
    data = request.json or {}
    email = data.get("email", "").strip()
    password = data.get("password", "")
    bank = data.get("bank", "UICBank")

    if not all([email, password]):
        return jsonify({"error": "MISSING_CREDENTIALS"}), 400

    account = mongo.db.BANK_ACCOUNTS.find_one({
        "email": email,
        "password": password,
        "bank": bank
    })

    if not account:
        return jsonify({"error": "BANK_AUTH_FAILED"}), 403

    return jsonify({"balance": account.get("balance", 0.0)})

# 💾 5. Download Thesis (with quota & balance check)
@consumer_bp.route("/thesis/download", methods=["POST"])
def download_thesis():
    data = request.json or {}
    title = data.get("title", "").strip()
    email = data.get("email", "").strip()
    password = data.get("password", "")
    bank = data.get("bank", "UICBank")

    if not all([title, email, password]):
        return jsonify({"error": "MISSING_FIELDS"}), 400

    # ✅ 1. 配额检查
    quota = mongo.db.USER_QUOTA.find_one({"user_email": email}) or {}
    used = quota.get("used_today", 0)
    max_daily = quota.get("max_daily", 5)
    if used >= max_daily:
        return jsonify({"error": "QUOTA_EXCEEDED", "used": used, "max": max_daily}), 403

    # ✅ 2. 获取论文信息
    thesis = mongo.db.THESIS.find_one({"title": {"$regex": title, "$options": "i"}})
    if not thesis:
        return jsonify({"error": "THESIS_NOT_FOUND"}), 404

    thesis_id = thesis.get("_id")
    price = thesis.get("price", 0)

    # ✅ 3. 获取 PDF 路径从 THESIS_FILES
    file_entry = mongo.db.THESIS_FILES.find_one({"title": {"$regex": title, "$options": "i"}})
    if not file_entry or not file_entry.get("pdf_path"):
        return jsonify({"error": "PDF_NOT_AVAILABLE"}), 404

    pdf_path = file_entry["pdf_path"]

    # ✅ 4. 验证银行账户并检查余额
    account = mongo.db.BANK_ACCOUNTS.find_one({
        "email": email,
        "password": password,
        "bank": bank
    })
    if not account:
        return jsonify({"error": "BANK_AUTH_FAILED"}), 403

    if account.get("balance", 0) < price:
        return jsonify({"error": "INSUFFICIENT_FUNDS"}), 402

    # ✅ 5. 扣费 & 记录购买
    mongo.db.BANK_ACCOUNTS.update_one(
        {"_id": account["_id"]},
        {"$inc": {"balance": -price}}
    )

    mongo.db.THESIS_PURCHASE.insert_one({
        "user_email": email,
        "thesis_id": thesis_id,
        "title": title,
        "price": price,
        "time": datetime.now(timezone.utc)
    })

    # ✅ 6. 更新用户配额
    mongo.db.USER_QUOTA.update_one(
        {"user_email": email},
        {"$inc": {"used_today": 1}, "$set": {"last_used": datetime.now(timezone.utc)}},
        upsert=True
    )

    # ✅ 7. 返回 PDF
    full_path = os.path.join(os.getcwd(), pdf_path)
    try:
        return send_file(
            full_path,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=f"{title.replace(' ', '_')}.pdf"
        )
    except Exception as e:
        return jsonify({"error": "FILE_ERROR", "detail": str(e)}), 500

# 🔎 3. View available services of an org
@consumer_bp.route("/services/<org>", methods=["GET"])
def get_services_by_org(org):
    services = ServiceConfig.find_by_org(org.lower())
    return jsonify(services)

# 🧠 4. Call a remote service (identity or record verification)
@consumer_bp.route("/service/query/<org>/<service_name>", methods=["POST"])
def use_service(org, service_name):
    email = get_user_email()
    user_doc = mongo.db.USERS.find_one({"email": email})
    if not user_doc:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    user = PrivateDataConsumer(user_doc)
    if not PrivateDataConsumer.is_eligible(user):
        return jsonify({"error": "FORBIDDEN"}), 403

    req_data = request.get_json()
    
    # ✅ 解包 "input" 字段，兼容数组或对象
    input_data = req_data.get("input") if isinstance(req_data, dict) and "input" in req_data else req_data

    try:
        result = user.access_service(service_name, org.lower(), input_data)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": f"DISPATCH_FAILED: {str(e)}"}), 500



# # 🔄 5. Public search proxy (reused)
# @consumer_bp.route("/courses/search", methods=["GET"])
# def search_courses():
#     keyword = request.args.get("keyword", "").strip()
#     consumer = PublicDataConsumer({})
#     return jsonify(consumer.search_courses(keyword))

@consumer_bp.route("/thesis/metadata", methods=["GET"])
def thesis_metadata():
    title = request.args.get("title", "").strip()
    thesis = mongo.db.THESIS.find_one({"title": {"$regex": title, "$options": "i"}})
    if not thesis:
        return jsonify({"message": "NOT_FOUND"})
    return jsonify({
        "thesis_id": thesis.get("_id"),
        "title": thesis.get("title"),
        "abstract": thesis.get("abstract"),
        "price": thesis.get("price", 0)
    })
