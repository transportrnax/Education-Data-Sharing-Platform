from flask import Blueprint, request, jsonify
from flask import current_app as app
from ..models.private_provider import PrivateDataProvider
from ..models.service_config import ServiceConfig
from ..models.course_info import CourseInfo
from ..services.NotificationService import NotificationService
from flask import render_template
from flask import g, request
from ..models.private_provider import PrivateDataProvider
from app.main.User import User
from ...extensions import mongo
from bson import ObjectId
from datetime import datetime, UTC
datauser_bp = Blueprint("datauser", __name__, url_prefix="/api/datauser")

@datauser_bp.route("/dashboard", methods=["GET"])
def provider_dashboard():
    return render_template("datauser/provider_dashboard.html")

@datauser_bp.route("/private_consumer", methods=["GET"])
def private_consumer():
    return render_template("datauser/private_consumer.html")

@datauser_bp.route("/public_consumer", methods=["GET"])
def public_consumer():
    return render_template("datauser/public_consumer.html")

@datauser_bp.before_request
# def inject_fake_user():
#     """
#     Local debug: inject fake PrivateDataProvider user
#     """
#     g.user = PrivateDataProvider.find_by_email("alice_huang@uic.edu.cn")

@datauser_bp.before_request
def inject_current_user_for_datauser():
    """
    Injects the current user into Flask's `g` object for datauser routes.
    Identifies user by X-User-Email header and instantiates the correct User subclass.
    Ensures g.user has organization_id and organization_name if applicable.
    """
    user_email_from_header = request.headers.get("X-User-Email")
    email_to_use = user_email_from_header or "alice_huang@uic.edu.cn" # Default for testing
    g.user = None 

    if not email_to_use:
        return

    user_doc = mongo.db.users.find_one({"email": email_to_use})

    if not user_doc:
        return

    access_level = user_doc.get('access_level', [])
    if len(access_level) > 2 and access_level[2] is True:
        g.user = PrivateDataProvider(user_doc)
    else:
        g.user = User(user_doc)

# Example: Get user context from request (assumes session management)
def get_current_user():
    # mock: replace with your actual login user system
    user_email = request.headers.get("X-User-Email")
    if not user_email:
        return None
    return PrivateDataProvider.find_by_email(user_email)

@datauser_bp.route("/course", methods=["POST"])
def add_course():
    user = g.user
    if not user or not PrivateDataProvider.is_eligible(user):
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    try:
        provider = PrivateDataProvider(user.__dict__)
        course_data = request.json or {}

        result = provider.add_course(course_data)
        return jsonify({
            "message": "ADDED" if result != "COURSE_ALREADY_EXISTS" else "DUPLICATE"
        })
    except Exception as e:
        print("❌ ERROR in add_course:", e)
        return jsonify({"error": "SERVER_ERROR", "details": str(e)}), 500


@datauser_bp.route("/course/<course_id>", methods=["PUT"])
def update_course(course_id):
    user = g.user
    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    data = request.json
    result = mongo.db["COURSE_INFO"].update_one(
        {"_id": course_id, "provider_email": user.email},
        {"$set": data}
    )

    if result.matched_count == 0:
        return jsonify({"message": "NOT_FOUND"}), 404
    return jsonify({"message": "UPDATED"})


@datauser_bp.route("/course/<course_id>", methods=["DELETE"])
def delete_course(course_id):
    user = g.user
    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401
    
    print("Trying to delete course:", course_id)
    print("Expected provider_email:", user.email)


    success = CourseInfo.delete_by_id(course_id, user.email)
    return jsonify({"message": "DELETED" if success else "NOT_FOUND"})


@datauser_bp.route("/courses", methods=["GET"])
def list_my_courses():
    # user = get_current_user()
    user = g.user

    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    results = CourseInfo.find_by_provider(user.email)
    return jsonify(results)


@datauser_bp.route("/service", methods=["POST"])
def configure_service():
    # user = get_current_user()
    user = g.user

    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    data = request.json
    required = {"service_name", "base_url", "path", "method", "input", "output"}
    if not data or not required.issubset(data):
        return jsonify({"error": "MISSING_FIELDS"}), 400

    config = ServiceConfig(
        provider_email=user.email,
        organization=user.email.split('@')[-1].split('.')[0],
        service_name=data["service_name"],
        config={
            "base_url": data["base_url"],
            "path": data["path"],
            "method": data["method"],
            "input": data["input"],
            "output": data["output"]
        }
    )
    config.save()
    return jsonify({"message": "SERVICE_CONFIGURED"})


@datauser_bp.route("/service/<service_name>", methods=["DELETE"])
def delete_service(service_name):
    # user = get_current_user()
    user = g.user

    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    success = ServiceConfig.delete(user.email, service_name)
    return jsonify({"message": "DELETED" if success else "NOT_FOUND"})


@datauser_bp.route("/services", methods=["GET"])
def list_my_services():
    # user = get_current_user()
    user = g.user

    if not user:
        return jsonify({"error": "AUTH_REQUIRED"}), 401

    configs = ServiceConfig.find_by_org(user.email.split('@')[-1].split('.')[0])
    return jsonify(configs)

@datauser_bp.route("/service/test/<service_name>", methods=["POST"])
def test_service(service_name):
    user = g.user
    if not user or not PrivateDataProvider.is_eligible(user):
        return jsonify({"error": "NOT_ALLOWED"}), 403
    provider = PrivateDataProvider(user.__dict__)
    test_input = request.json or {}
    result = provider.test_service_config(service_name, test_input)
    return jsonify(result)

@datauser_bp.route("/notifications", methods=["GET"])
def get_provider_notifications_route():
    user = getattr(g, 'user', None)
    #print(type(user))
    if not user or not isinstance(user, PrivateDataProvider):
        return jsonify({"error": "AUTH_REQUIRED or Invalid user type"}), 403

    if not getattr(user, 'organization', None):
        return jsonify({"error": "User not associated with an organization name"}), 400
    # print(user.username)
    # print(user.organization)
    # print(user.email)
    unread_notifications = NotificationService.get_org_unread_notifications(user.organization)
    return jsonify(unread_notifications)


@datauser_bp.route("/notifications/mark-read/<notification_id_str>", methods=["POST"])
def mark_notification_as_read_route(notification_id_str):
    user = getattr(g, 'user', None)

    if not user or not isinstance(user, PrivateDataProvider): # Or any authenticated user who can mark org notifications
        return jsonify({"error": "AUTH_REQUIRED or Invalid user type"}), 403
    #print(user.organization)
    if not getattr(user, 'organization', None):
        return jsonify({"error": "User not associated with an organization name"}), 400
        
    try:
        # Pass user object for potential permission checks or logging within service
        success, message = NotificationService.mark_org_notification_read(user, notification_id_str)
        if success:
            return jsonify({"message": message}), 200
        else:
            status_code = 404 if "not found" in message.lower() else 400
            return jsonify({"error": message}), status_code
    except Exception as e:
        return jsonify({"error": "Failed to mark notification as read"}), 500